# 🛒 ShopEZ – E-Commerce Application (Final Phase)

## 1. Project Overview

**ShopEZ** is a scalable, enterprise-level **E-Commerce Application** developed using **Microservices Architecture**. This project transforms a traditional monolithic backend into independent services to improve **performance, scalability, maintainability, and deployment flexibility**.

The application demonstrates modern backend engineering concepts including:

- Microservices Architecture
- API Gateway Integration
- Dapper ORM Optimization
- Unit Testing & Mocking
- Docker Containerization
- REST API Communication

---

# 2. Objective

The primary objective of this project is to evolve the backend into a **scalable microservices ecosystem**, ensure reliability through structured testing, and enable containerized deployment.

---

# 3. Key Enhancements

## 1️⃣ Backend Refactoring into Microservices

The monolithic backend is divided into independent services:

### 🔹 User Service
Handles:
- User Registration
- Authentication
- JWT Token Generation
- User Profile Management

### 🔹 Product Service
Handles:
- Product Catalog
- Product Search
- Filtering
- Pagination

### 🔹 Order Service
Handles:
- Order Creation
- Order History
- Order Tracking

### 🔹 Cart Service
Handles:
- Cart Management
- Add/Remove Items
- Quantity Updates

### Additional Enhancements
✅ REST-Based Communication  
✅ API Gateway (Ocelot / YARP)

---

## 2️⃣ Dapper Integration (Performance Optimization)

Dapper is implemented in the **Product Service** for optimized query execution.

### Why Dapper?
- Lightweight ORM
- Faster than Entity Framework
- Better performance for read-heavy operations

### Use Cases
- Product Listing
- Product Search
- Filtering
- Pagination Queries

---

## 3️⃣ Unit Testing

Structured unit testing is implemented across all microservices.

### Testing Frameworks
- **xUnit / NUnit**
- **Moq** (Dependency Mocking)

### Testing Coverage

#### Service Layer Testing
- Business Logic Validation
- Edge Case Handling

Examples:
- Empty cart validation
- Invalid order creation
- Login validation

#### Repository Layer Testing
- Mock Database Operations
- Validate Dapper Queries

#### Controller/API Testing
- Endpoint Testing
- Status Code Validation

Examples:
- `200 OK`
- `400 Bad Request`
- `404 Not Found`

### Example Test Scenarios
✔ User registration with valid/invalid input  
✔ Product filtering works correctly  
✔ Order fails with empty cart  
✔ Cart updates after item modification

---

# 4. System Architecture

```text
Angular SPA (Frontend)
            ↓
       API Gateway
            ↓
------------------------------------------------
| User | Product | Order | Cart | Payment |
------------------------------------------------
            ↓
     Databases (Per Service)
```

### 5.Architecture Features
- Independent Services
- Database Per Service
- REST Communication
- Scalable Deployment
- Fault Isolation

---

#  6. Technology Stack

## Backend
- ASP.NET Core Web API
- C#

## Frontend
- Angular

## Database
- SQL Server

## ORM
- Dapper (Product Service)

## Testing
- xUnit / NUnit
- Moq

## API Gateway
- Ocelot / YARP

## DevOps
- Docker
- Docker Compose

---

# 7. Project Structure

```text
/services
│
├── user-service
│   ├── Controllers
│   ├── Services
│   ├── Repositories
│   └── Tests
│
├── product-service
│   ├── Controllers
│   ├── Services
│   ├── Repositories
│   └── Tests
│
├── order-service
│   ├── Controllers
│   ├── Services
│   ├── Repositories
│   └── Tests
│
├── cart-service
│   ├── Controllers
│   ├── Services
│   ├── Repositories
│   └── Tests
│
├── api-gateway
│
└── docker
    └── docker-compose.yml
```

---

# 8. Unit Testing

The project includes structured testing across all services.

### Tested Components
- Controllers
- Services
- Repositories

### Testing Goals
✔ Validate Business Logic  
✔ Handle Edge Cases  
✔ Ensure API Reliability

---

# 9. Docker Containerization

Each service is containerized using Docker.

### Includes
- Dockerfile per service
- Docker Compose orchestration
- Database containers

### Run with Docker

```bash
docker-compose up --build
```

---

# 10. Authentication & Authorization

Security is implemented using:

- JWT Authentication
- Role-Based Access Control (RBAC)

### Roles
- User
- Admin


# 11. Deliverables

- Microservices-Based Backend  
- API Gateway Integration  
- Dapper Implementation  
- Unit Testing with Moq  
- Dockerized Application  
- Technical Documentation

---

# 12. Skills Demonstrated

- Microservices Architecture
- Clean Code Principles
- Unit Testing & Mocking
- Performance Optimization
- Docker Containerization
- REST API Design
- API Gateway Implementation

---

# ``13. Future Enhancements

- Payment Gateway Integration
- Redis Caching
- Kafka / RabbitMQ Messaging
- Kubernetes Deployment
- AI-Based Product Recommendation

---

# 14. Author

**Ankit Kumar**

Final Training Project – ShopEZ E-Commerce Application

---

## ⭐ If you found this project useful, give it a star!