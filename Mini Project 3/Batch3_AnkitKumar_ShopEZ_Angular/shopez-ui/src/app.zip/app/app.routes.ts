import { Routes } from '@angular/router';

// Guards
import { AuthGuard } from './guards/auth.guard';
import { adminGuard } from './guards/admin.guard';

export const routes: Routes = [

  // ======================
  // PUBLIC ROUTES (LAZY)
  // ======================
  {
    path: '',
    loadComponent: () =>
      import('./pages/home/home.component')
        .then(m => m.HomeComponent)
  },

  {
    path: 'products',
    loadComponent: () =>
      import('./components/product-list/product-list.component')
        .then(m => m.ProductListComponent)
  },

  {
    path: 'products/:id',
    loadComponent: () =>
      import('./components/product-details/product-details.component')
        .then(m => m.ProductDetailsComponent)
  },

  {
    path: 'login',
    loadComponent: () =>
      import('./pages/login/login.component')
        .then(m => m.LoginComponent)
  },

  {
    path: 'register',
    loadComponent: () =>
      import('./pages/register/register.component')
        .then(m => m.RegisterComponent)
  },

  // ======================
  // USER PROTECTED ROUTES
  // ======================
  {
    path: 'cart',
    canActivate: [AuthGuard],
    loadComponent: () =>
      import('./components/cart/cart.component')
        .then(m => m.CartComponent)
  },

  {
    path: 'checkout',
    canActivate: [AuthGuard],
    loadComponent: () =>
      import('./components/checkout/checkout.component')
        .then(m => m.CheckoutComponent)
  },

  {
    path: 'orders',
    canActivate: [AuthGuard],
    loadComponent: () =>
      import('./components/order-history/order-history.component')
        .then(m => m.OrderHistoryComponent)
  },

  {
    path: 'payment',
    loadComponent: () =>
      import('./components/payment/payment.component')
        .then(m => m.PaymentComponent)
  },

  {
    path: 'order-success',
    loadComponent: () =>
      import('./components/order-success/order-success.component')
        .then(m => m.OrderSuccessComponent)
  },

  // ======================
// ADMIN ROUTES (LAYOUT BASED)
// ======================
{
  path: 'admin',
  canActivate: [adminGuard],
  loadComponent: () =>
    import('./admin/admin-layout.component')
      .then(m => m.AdminLayoutComponent),
  children: [
    {
      path: '',
      loadComponent: () =>
        import('./pages/admin/admin.component')
          .then(m => m.AdminComponent)
    },
    {
      path: 'products',
      loadComponent: () =>
        import('./components/admin-products/admin-products.component')
          .then(m => m.AdminProductsComponent)
    },
    {
      path: 'orders',
      loadComponent: () =>
        import('./components/admin-orders/admin-orders.component')
          .then(m => m.AdminOrdersComponent)
    }
  ]
}
,
  // ======================
  // FALLBACK
  // ======================

  {
    
    path: '**',
    redirectTo: ''
  }
];
