import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { finalize, catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { Router } from '@angular/router';

import { LoaderService } from '../services/loader.service';
import { ToastrService } from 'ngx-toastr';

export const AuthInterceptor: HttpInterceptorFn = (req, next) => {

  const loader = inject(LoaderService);
  const toastr = inject(ToastrService);
  const router = inject(Router);

  const token = localStorage.getItem('token');

  // 🔥 SHOW LOADER
  loader.show();

  let modifiedReq = req;

  // Attach token if exists
  if (token && token !== 'undefined') {
    modifiedReq = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });
  }

  return next(modifiedReq).pipe(

    catchError((err) => {

      console.error('HTTP ERROR:', err);

      if (err.status === 401) {

        toastr.error('Session expired. Please login again');

        localStorage.removeItem('token');
        localStorage.removeItem('user');

        if (router.url !== '/login') {
          router.navigate(['/login']);
        }
      }

      else if (err.status === 403) {
        toastr.error('Access denied');
      }

      else if (err.error?.message) {
        toastr.error(err.error.message);
      }

      else {
        toastr.error('Something went wrong!');
      }

      return throwError(() => err);
    }),

    finalize(() => {
      // 🔥 HIDE LOADER
      loader.hide();
    })
  );
};