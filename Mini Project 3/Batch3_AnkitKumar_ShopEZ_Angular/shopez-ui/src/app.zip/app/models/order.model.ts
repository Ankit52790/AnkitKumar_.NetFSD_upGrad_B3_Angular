import { CartItem } from './cart-item.model';

export interface OrderItem {
  productId: number;
  quantity: number;
  price?: number;
}

export interface Order {
  orderId?: number;
  userId: number;
  orderDate?: string;
  totalAmount: number;
  orderItems: OrderItem[];
}