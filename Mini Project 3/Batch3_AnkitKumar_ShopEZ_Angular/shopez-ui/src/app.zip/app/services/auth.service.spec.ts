import { TestBed } from '@angular/core/testing';
import { AuthService } from './auth.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { vi } from 'vitest';

describe('AuthService', () => {

  let service: AuthService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule]
    });

    service = TestBed.inject(AuthService);

    localStorage.clear();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return user role correctly', () => {
    vi.spyOn(service, 'getUser').mockReturnValue({ role: 'Admin' });

    expect(service.getUserRole()).toBe('Admin');
  });

  it('should detect admin', () => {
    vi.spyOn(service, 'getUserRole').mockReturnValue('admin');

    expect(service.isAdmin()).toBeTruthy();
  });

  it('should detect login state', () => {

  localStorage.setItem('token', 'token123');

  expect(service.isLoggedIn()).toBeTruthy();

});

});