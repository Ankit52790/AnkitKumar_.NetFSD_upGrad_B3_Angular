import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private api = `${environment.apiUrl}/authenticate`;

  constructor(private http: HttpClient) {}

  // ======================
  // LOGIN
  // ======================
  login(data: any) {
    return this.http.post<any>(`${this.api}/login`, data).pipe(
      map((res) => {

        const token = res?.token || res?.data?.token;
        const user = res?.user || res?.data?.user;

        if (!token) {
          throw new Error('Token missing in response');
        }

        const safeUser = user || { userId: 0, role: 'User' };

        localStorage.setItem('token', token);
        localStorage.setItem('user', JSON.stringify(safeUser));

        return { token, user: safeUser };
      })
    );
  }

  // ======================
  // REGISTER (DEFAULT USER ROLE)
  // ======================
  register(data: any) {
    const payload = {
      ...data,
      role: 'User'   // default role
    };

    return this.http.post(`${this.api}/register`, payload);
  }

  // ======================
  // USER HELPERS (SINGLE SOURCE)
  // ======================
  getUser(): any {
    try {
      return JSON.parse(localStorage.getItem('user') || 'null');
    } catch {
      return null;
    }
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }

  getUserRole(): string {
    return this.getUser()?.role || 'User';
  }

  // ======================
  // ROLE CHECKS
  // ======================
  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  isAdmin(): boolean {
    return this.getUserRole().toLowerCase() === 'admin';
  }

  isUser(): boolean {
    return this.isLoggedIn() && !this.isAdmin();
  }

  // ======================
  // LOGOUT
  // ======================
  logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  }
}