import { Injectable } from '@angular/core';
import { CartItem } from '../models/cart-item.model';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  private items: CartItem[] = [];

  // Reactive cart count
  private cartCount = new BehaviorSubject<number>(0);
  cartCount$ = this.cartCount.asObservable();

  constructor() {
    this.items = this.loadCart();
    this.updateCartCount();
  }

  // =========================
  // SAVE CART
  // =========================
  private saveCart(): void {
    localStorage.setItem('cart', JSON.stringify(this.items));
    this.updateCartCount(); // 🔥 IMPORTANT FIX
  }

  // =========================
  // LOAD CART
  // =========================
  private loadCart(): CartItem[] {
    const data = localStorage.getItem('cart');
    return data ? JSON.parse(data) : [];
  }

  // =========================
  // UPDATE REACTIVE COUNT
  // =========================
  private updateCartCount(): void {
    const count = this.items.reduce((sum, item) => sum + item.quantity, 0);
    this.cartCount.next(count);
  }

  // =========================
  // ADD ITEM
  // =========================
  add(item: CartItem): void {

    const existing = this.items.find(i => i.productId === item.productId);

    if (existing) {
      existing.quantity += item.quantity;
    } else {
      this.items.push({
        ...item,
        quantity: item.quantity || 1
      });
    }

    this.saveCart();
  }

  // =========================
  // GET ITEMS
  // =========================
  getItems(): CartItem[] {
    return [...this.items];
  }

  // =========================
  // UPDATE QTY
  // =========================
  updateQuantity(productId: number, quantity: number): void {

    const item = this.items.find(i => i.productId === productId);

    if (item) {
      item.quantity = quantity;
      this.saveCart();
    }
  }

  // =========================
  // REMOVE ITEM
  // =========================
  remove(productId: number): void {

    this.items = this.items.filter(i => i.productId !== productId);
    this.saveCart();
  }

  // =========================
  // CLEAR CART
  // =========================
  clear(): void {
    this.items = [];
    this.saveCart();
  }

  // =========================
  // TOTAL
  // =========================
  getTotal(): number {
    return this.items.reduce(
      (sum, item) => sum + (item.price ?? 0) * item.quantity,
      0
    );
  }

  // =========================
  // COUNT (non-reactive fallback)
  // =========================
  getCount(): number {
    return this.items.reduce((sum, item) => sum + item.quantity, 0);
  }
}