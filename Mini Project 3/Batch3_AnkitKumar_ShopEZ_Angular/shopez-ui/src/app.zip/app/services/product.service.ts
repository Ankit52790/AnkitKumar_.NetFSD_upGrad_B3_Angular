import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Product } from '../models/product.model';
import { environment } from '../../environments/environment';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private API_URL = `${environment.apiUrl}/products`;

  constructor(private http: HttpClient) {}

  // =========================
  // GET ALL PRODUCTS
  // =========================
  getProducts() {
    return this.http.get<any>(`${this.API_URL}`).pipe(
      map(res => this.mapProducts(res))
    );
  }

  // =========================
  // FILTER PRODUCTS (BEST PRACTICE)
  // =========================
  getFilteredProducts(
  category: string = 'all',
  search: string = '',
  minPrice?: number,
  maxPrice?: number
) {
  let params = new HttpParams();

  if (category && category !== 'all') {
    params = params.set('category', category);
  }

  if (search) {
    params = params.set('search', search);
  }

  if (minPrice !== undefined) {
    params = params.set('minPrice', minPrice);
  }

  if (maxPrice !== undefined) {
    params = params.set('maxPrice', maxPrice);
  }

  return this.http.get<any>(this.API_URL, { params }).pipe(
    map(res => this.mapProducts(res))
  );
}

  // =========================
  // GET PRODUCT BY ID
  // =========================
  getProductById(id: number) {
    return this.http.get<any>(`${this.API_URL}/${id}`).pipe(
      map(res => {
        const p = res?.data ?? res;
        return {
          ...p,
          id: p.productId
        };
      })
    );
  }

  // =========================
  // ADMIN CRUD
  // =========================
  addProduct(product: Product) {
    return this.http.post<any>(this.API_URL, product);
  }

  updateProduct(id: number, product: Product) {
    return this.http.put<any>(`${this.API_URL}/${id}`, product);
  }

  deleteProduct(id: number) {
    return this.http.delete<any>(`${this.API_URL}/${id}`);
  }

  // =========================
  // COMMON MAPPER
  // =========================
  private mapProducts(res: any) {
  const products = res?.data ?? res;

  if (!Array.isArray(products)) {
    return [];
  }

  return products.map((p: any) => ({
    ...p,
    id: p.productId
  }));
}
}