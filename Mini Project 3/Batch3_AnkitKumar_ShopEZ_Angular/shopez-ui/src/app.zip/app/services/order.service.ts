import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Product } from '../models/product.model';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpHeaders } from '@angular/common/http';

@Injectable({ 
  providedIn: 'root' 
})

export class OrderService {

  private api = `${environment.apiUrl}/orders`;

  constructor(private http: HttpClient) {}

getOrdersByUser(userId: number) {
  return this.http.get<any>(
    `${this.api}/user/${userId}`,
    this.getAuthHeaders()
  );
}

getAuthHeaders() {
  const token = localStorage.getItem('token');
  return {
    headers: new HttpHeaders({
      Authorization: `Bearer ${token}`
    })
  };
}
// PLACE ORDER
  placeOrder(order: any) {
  return this.http.post(this.api, order); //interceptor handles token
}

  // GET LOGGED-IN USER ORDERS (CORRECT WAY)
  getMyOrders(): Observable<any[]> {
  return this.http.get<any>(`${this.api}/my-orders`).pipe(
    map(res => res.data)
  );
}

getAllOrders(): Observable<any[]> {
  return this.http.get<any>(this.api).pipe(
    map(res => res.data)
  );
}

}
