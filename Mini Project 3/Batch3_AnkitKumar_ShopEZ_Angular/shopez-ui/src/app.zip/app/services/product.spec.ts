import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ProductService } from './product.service';

describe('ProductService', () => {

  let service: ProductService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule]
    });

    service = TestBed.inject(ProductService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  it('should fetch products', () => {

    const mockProducts = [
      { id: 1, name: 'Phone', price: 1000 }
    ];

    service.getProducts().subscribe(data => {
      expect(data.length).toBe(1);
    });

    const req = httpMock.expectOne('https://localhost:7110/api/products');
    req.flush(mockProducts);
  });

});