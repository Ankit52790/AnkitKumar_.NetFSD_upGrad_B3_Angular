import { TestBed } from '@angular/core/testing';
import { CartService } from './cart.service';

describe('CartService', () => {

  let service: CartService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CartService);

    service.clear(); // reset state
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should add item to cart', () => {

    service.add({
      productId: 1,
      name: 'Phone',
      price: 1000,
      quantity: 1
    });

    expect(service.getItems().length).toBe(1);
  });

  it('should calculate total correctly', () => {

    service.add({
      productId: 1,
      name: 'Phone',
      price: 1000,
      quantity: 2
    });

    expect(service.getTotal()).toBe(2000);
  });

  it('should clear cart', () => {

    service.add({
      productId: 1,
      name: 'Phone',
      price: 1000,
      quantity: 1
    });

    service.clear();

    expect(service.getItems().length).toBe(0);
  });

});