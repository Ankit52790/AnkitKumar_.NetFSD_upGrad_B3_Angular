import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { map } from 'rxjs/operators';

@Injectable({
     providedIn: 'root'
     })
     
export class AdminService {

  private api = environment.apiUrl;

  constructor(private http: HttpClient) {}

  getProductCount() {
    return this.http.get<any>(`${this.api}/products/count`);
  }

  getOrderCount() {
    return this.http.get<any>(`${this.api}/orders/count`);
  }

  getRevenue() {
    return this.http.get<any>(`${this.api}/orders/revenue`);
  }

  getUserCount() {
    return this.http.get<any>(`${this.api}/users/count`);
  }
}