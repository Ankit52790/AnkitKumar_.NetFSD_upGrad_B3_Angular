import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  getUser() {
    return JSON.parse(localStorage.getItem('user') || '{}');
  }

  getUserId(): number {
    const user = this.getUser();
    return user?.id;
  }

  getToken(): string {
    return localStorage.getItem('token') || '';
  }
}