import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import {
  ReactiveFormsModule,
  FormBuilder,
  FormGroup,
  Validators,
  AbstractControl,
  ValidationErrors
} from '@angular/forms';

import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './register.html',
  styleUrls: ['./register.css']
})
export class RegisterComponent implements OnInit {

  registerForm!: FormGroup;

  error = '';
  success = '';
  loading = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    
    this.registerForm = this.fb.group(
      {
        name: ['', [Validators.required, Validators.minLength(3)]],
        email: ['', [Validators.required, Validators.email]],
        password: [
          '',
          [
            Validators.required,
            Validators.minLength(6),
            Validators.pattern('^(?=.*[A-Z])(?=.*[0-9]).{6,}$')
          ]
        ],
        confirmPassword: ['', Validators.required] 
      },
      {
        validators: this.passwordMatchValidator 
      }
    );
  }

  get f() {
    return this.registerForm.controls;
  }

  register() {
    this.error = '';
    this.success = '';

    if (this.registerForm.invalid) {
      this.registerForm.markAllAsTouched();
      return;
    }

    this.loading = true;

    // Optionally remove confirmPassword before sending to backend
    const { confirmPassword, ...payload } = this.registerForm.value;

    this.authService.register(payload).subscribe({
      next: () => {
        this.loading = false;

        this.safeSuccess('Registration successful! Redirecting...');

        setTimeout(() => {
          this.router.navigate(['/login']);
        }, 1200);
      },

      error: () => {
        this.loading = false;
        this.safeError('Registration failed. Please try again.');
      }
    });
  }

  // Password match validator
  private passwordMatchValidator(control: AbstractControl): ValidationErrors | null {
    const password = control.get('password')?.value;
    const confirmPassword = control.get('confirmPassword')?.value;

    if (!password || !confirmPassword) return null;

    return password === confirmPassword ? null : { mismatch: true };
  }

  // NG0100 safe updates
  private safeError(msg: string) {
    setTimeout(() => {
      this.error = msg;
    });
  }

  private safeSuccess(msg: string) {
    setTimeout(() => {
      this.success = msg;
    });
  }
}