import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductService } from '../../services/product.service';
import { RouterModule } from '@angular/router';
import { LoaderService } from '../../services/loader.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './home.component.html',
  styleUrls: ['./home.css']
})
export class HomeComponent implements OnInit {

  featuredProducts: any[] = [];

  constructor(
    private productService: ProductService,
    public loader: LoaderService
  ) {}

  ngOnInit(): void {
    this.getFeaturedProducts();
  }

  getFeaturedProducts(): void {

    // SHOW GLOBAL LOADER
    this.loader.show();

    this.productService.getProducts().subscribe({
      next: (data) => {
        this.featuredProducts = data.slice(0, 4);

        // HIDE LOADER
        this.loader.hide();
      },
      error: (err) => {
        console.error(err);

        // HIDE LOADER EVEN ON ERROR
        this.loader.hide();
      }
    });
  }

  getImageUrl(url: string): string {

    if (!url) {
      return 'assets/images/products/placeholder.jpg';
    }

    if (url.startsWith('http')) {
      return url;
    }

    return url.startsWith('assets/')
      ? url
      : `assets/images/products/${url}`;
  }
}