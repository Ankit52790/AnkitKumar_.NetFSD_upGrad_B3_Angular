import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminService } from '../../services/admin.service';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './admin.html',
  styleUrls: ['./admin.css']
})
export class AdminComponent implements OnInit {

  productCount = 0;
  orderCount = 0;
  revenue = 0;
  userCount = 0;

  loading = true;

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    this.loadDashboard();
  }

  loadDashboard() {

    this.adminService.getProductCount().subscribe(res => {
      this.productCount = res.data;
    });

    this.adminService.getOrderCount().subscribe(res => {
      this.orderCount = res.data;
    });

    this.adminService.getRevenue().subscribe(res => {
      this.revenue = res.data;
    });

    this.adminService.getUserCount().subscribe(res => {
      this.userCount = res.data;
      this.loading = false; // FIXED HERE
    });
  }
}