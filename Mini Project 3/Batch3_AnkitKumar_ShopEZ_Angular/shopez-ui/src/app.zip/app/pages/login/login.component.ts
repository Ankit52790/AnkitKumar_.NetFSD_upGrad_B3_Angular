import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, ActivatedRoute, RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule], // ✅ FIX HERE
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})
export class LoginComponent {

  email = '';
  password = '';
  error = '';
  loading = false;

  constructor(
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef
  ) {}

  login() {

    this.error = '';

    if (!this.email || !this.password) {
      this.error = 'Email and password required';
      return;
    }

    this.loading = true;

    this.authService.login({
      email: this.email,
      password: this.password
    }).subscribe({

      next: (res: any) => {

        Promise.resolve().then(() => {

          this.loading = false;

          const token = res?.token || res?.data?.token;
          if (token) {
            localStorage.setItem('token', token);
          }

          const user = res?.user || res?.data?.user;
          const returnUrl = this.route.snapshot.queryParams['returnUrl'];

          if (user?.role === 'Admin') {
            this.router.navigate(['/admin/products']);
          } else if (returnUrl) {
            this.router.navigateByUrl(returnUrl);
          } else {
            this.router.navigate(['/']);
          }

        });

      },

      error: () => {
        Promise.resolve().then(() => {
          this.loading = false;
          this.error = 'Invalid email or password';
        });
      }
    });
  }
}