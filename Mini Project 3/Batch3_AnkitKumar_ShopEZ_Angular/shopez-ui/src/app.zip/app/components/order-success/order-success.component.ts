import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-order-success',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './order-success.component.html',
  styleUrl: './order-success.css'
})
export class OrderSuccessComponent implements OnInit {

  orderId: string = '';
  orderTotal: number = 0;

  ngOnInit() {

    // Get data from localStorage
    this.orderTotal = Number(localStorage.getItem('orderTotal') || 0);

    this.orderId = 'ORD' + Math.floor(100000 + Math.random() * 900000);

    // Clear after use
    localStorage.removeItem('orderTotal');

    // Confetti effect
    this.launchConfetti();
  }

  launchConfetti() {
    const script = document.createElement('script');
    script.src = 'https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js';
    script.onload = () => {
      (window as any).confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.6 }
      });
    };
    document.body.appendChild(script);
  }
}