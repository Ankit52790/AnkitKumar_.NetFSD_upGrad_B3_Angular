import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { CartService } from '../../services/cart.service';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-checkout',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './checkout.html',
  styleUrls: ['./checkout.css'],
})
export class CheckoutComponent implements OnInit {

  checkoutForm!: FormGroup;
  loading = false;

  cartItems: any[] = [];
  total: number = 0;

  constructor(
    private fb: FormBuilder,
    private cartService: CartService,
    private router: Router,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.cartItems = this.cartService.getItems();
    this.calculateTotal();

    this.checkoutForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      address: ['', [Validators.required, Validators.minLength(10)]],
      phone: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]]
    });
  }

  calculateTotal() {
    this.total = this.cartItems.reduce(
      (sum, item) => sum + item.price * item.quantity,
      0
    );
  }

  placeOrder() {

    if (this.checkoutForm.invalid) {
      this.toastr.error('Please fill all fields correctly');
      return;
    }

    if (!this.cartItems.length) {
      this.toastr.warning('Cart is empty!');
      return;
    }

    //  check token instead of user object
    const token = localStorage.getItem('token');

    if (!token) {
      this.toastr.error('Please login first!');
      this.router.navigate(['/login']);
      return;
    }

    // OPTIONAL: still get user if available
    const userRaw = localStorage.getItem('user');
    const user = userRaw ? JSON.parse(userRaw) : null;

    const order = {
      // backend can extract from token anyway
      totalAmount: this.total,
      orderItems: this.cartItems.map(item => ({
        productId: item.productId,
        quantity: item.quantity
      }))
    };

    // Navigate to payment
    this.router.navigate(['/payment'], {
      state: { orderData: order }
    });
  }
}