import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { OrderService } from '../../services/order.service';
import { ToastrService } from 'ngx-toastr';
import { CartService } from '../../services/cart.service';

@Component({
  selector: 'app-payment',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.css']
})
export class PaymentComponent {

  paymentMethod: string = 'upi';

  upi = '';
  cardNumber = '';
  cardName = '';
  expiry = '';
  cvv = '';

  orderData: any;

  constructor(
    private router: Router,
    private orderService: OrderService,
    private toastr: ToastrService,
    private cartService: CartService
  ) {
    this.orderData = this.router.getCurrentNavigation()?.extras?.state?.['orderData'];
  }

  selectMethod(method: string) {
    this.paymentMethod = method;
  }

  payNow() {

    if (!this.orderData) {
      this.toastr.error('Order data missing');
      this.router.navigate(['/checkout']);
      return;
    }

    if (this.paymentMethod === 'upi' && !this.upi) {
      this.toastr.error('Enter UPI ID');
      return;
    }

    if (this.paymentMethod === 'card') {
      if (!this.cardNumber || !this.cardName || !this.expiry || !this.cvv) {
        this.toastr.error('Fill all card details');
        return;
      }
    }

    // SINGLE API CALL (IMPORTANT FIX)
    this.orderService.placeOrder(this.orderData).subscribe({
      next: () => {

        this.toastr.success('Payment successful & Order placed!');

        this.cartService.clear();

        this.router.navigate(['/order-success']);
      },

      error: (err) => {
        console.error(err);
        this.toastr.error('Payment failed');
      }
    });
  }
}