import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../../services/product.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-admin-products',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-products.html',
  styleUrls: ['./admin-products.css'],
})
export class AdminProductsComponent {

  products: any[] = [];

  form: any = {
    name: '',
    description: '',
    price: 0,
    imageUrl: '',
    stock: 0
  };

  editMode = false;
  editId: number | null = null;

  constructor(private productService: ProductService, private toastr: ToastrService) {}

  ngOnInit() {
    this.loadProducts();
  }

  loadProducts() {
    this.productService.getProducts().subscribe((res: any) => {
      this.products = res.data || res; // handle backend response
    });
  }

  submit() {
    if (this.editMode) {
      this.productService.updateProduct(this.editId!, this.form).subscribe(() => {
        alert('Product updated');
        this.resetForm();
        this.loadProducts();
      });
    } else {
      this.productService.addProduct(this.form).subscribe(() => {
        alert('Product added');
        this.resetForm();
        this.loadProducts();
      });
    }
  }

  edit(product: any) {
    this.form = { ...product };
    this.editMode = true;
    this.editId = product.productId;
  }

  delete(id: number) {
    if (confirm('Delete this product?')) {
      this.productService.deleteProduct(id).subscribe(() => {
        alert('Deleted');
        this.loadProducts();
      });
    }
  }

  resetForm() {
    this.form = {
      name: '',
      description: '',
      price: 0,
      imageUrl: '',
      stock: 0
    };
    this.editMode = false;
    this.editId = null;
  }
}