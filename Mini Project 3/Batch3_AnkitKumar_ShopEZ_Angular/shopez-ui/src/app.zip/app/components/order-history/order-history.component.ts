import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrderService } from '../../services/order.service';
import { RouterModule } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-order-history',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './order-history.html',
  styleUrls: ['./order-history.css'],
})
export class OrderHistoryComponent implements OnInit {

  orders: any[] = [];
  loading = true;
  error = '';

  constructor(private orderService: OrderService, private toastr: ToastrService) {}

  ngOnInit(): void {
    this.loadOrders();
  }

  loadOrders() {
  const userId = 1; // later from login

  this.orderService.getMyOrders().subscribe({
  next: (orders) => {
    this.orders = orders;
    this.loading = false;
  },
  error: (err) => {
    console.error(err);
    this.toastr.error ('Failed to load orders');
    this.loading = false;
  }
});
}
}