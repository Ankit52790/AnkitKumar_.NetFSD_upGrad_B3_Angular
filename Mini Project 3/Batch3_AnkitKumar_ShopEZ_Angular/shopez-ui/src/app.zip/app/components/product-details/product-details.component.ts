import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterModule } from '@angular/router';

import { ProductService } from '../../services/product.service';
import { CartService } from '../../services/cart.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-product-details',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './product-details.html'
})
export class ProductDetailsComponent implements OnInit {

  product: any = null;
  loading = true;
  error = '';

  constructor(
    private route: ActivatedRoute,
    private productService: ProductService,
    private cartService: CartService,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      const id = Number(params.get('id'));
      this.loadProduct(id);
    });
  }

  loadProduct(id: number) {
    this.loading = true;

    this.productService.getProductById(id).subscribe({
      next: (data) => {
        this.product = data;
        this.loading = false;
      },
      error: () => {
        this.error = 'Product not found';
        this.toastr.error('Product not found');
        this.loading = false;
      }
    });
  }

  addToCart() {

  const user = localStorage.getItem('user');

  if (!user) {
    this.toastr.warning('Please login first');
    return;
  }

  this.cartService.add({
    productId: this.product.id,
    name: this.product.name,
    price: this.product.price,
    imageUrl: this.product.imageUrl,
    quantity: 1
  });

  this.toastr.success('Added to cart!');
}
}