import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-banner',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './banner.component.html',
  styleUrls: ['./banner.css']
})
export class BannerComponent {

  banners: string[] = [
    'assets/images/banners/banner1.png',
    'assets/images/banners/banner2.png',
    'assets/images/banners/banner3.jpg',
    'assets/images/banners/banner4.png'
  ];

  constructor(private router: Router) {}

  getImage(img: string): string {
    return img || 'assets/images/banners/banner1.png';
  }

  // NAVIGATION FUNCTION
  goToProducts() {
    this.router.navigate(['/products']);
  }
}