import { TestBed } from '@angular/core/testing';
import { CartComponent } from './cart.component';
import { ToastrService } from 'ngx-toastr';
import { CartService } from '../../services/cart.service';
import { of } from 'rxjs';
import { RouterTestingModule } from '@angular/router/testing';
import { vi } from 'vitest';

describe('CartComponent', () => {

  let component: CartComponent;
  let fixture: any;

  const cartServiceMock = {
    getItems: vi.fn().mockReturnValue([]),
    clear: vi.fn(),
    removeItem: vi.fn(),
    cartCount$: of(0)
  };

  const toastrMock = {
    success: vi.fn(),
    error: vi.fn(),
    info: vi.fn()
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CartComponent, RouterTestingModule],
      providers: [
        { provide: CartService, useValue: cartServiceMock },
        { provide: ToastrService, useValue: toastrMock }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(CartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

});