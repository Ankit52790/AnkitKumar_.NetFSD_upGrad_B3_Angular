import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { CartService } from '../../services/cart.service';
import { CartItem } from '../../models/cart-item.model';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './cart.html',
  styleUrls: ['./cart.css'],
})
export class CartComponent {

  items: CartItem[] = [];

  constructor(
    private cartService: CartService,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.loadCart();
  }

  loadCart() {
    this.items = this.cartService.getItems();
  }

  removeItem(productId: number) {
    this.cartService.remove(productId);
    this.loadCart();
    this.toastr.warning('Item removed from cart');
  }

  clearCart() {
    this.cartService.clear();
    this.loadCart();
    this.toastr.info('Cart cleared');
  }

  getTotal() {
    return this.items.reduce(
      (sum, item) => sum + item.price * item.quantity,
      0
    );
  }

  increase(item: CartItem) {
    this.cartService.updateQuantity(item.productId, item.quantity + 1);
    this.loadCart();
  }

  decrease(item: CartItem) {
    if (item.quantity > 1) {
      this.cartService.updateQuantity(item.productId, item.quantity - 1);
    } else {
      this.removeItem(item.productId);
    }
    this.loadCart();
  }
}