import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrderService } from '../../services/order.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-admin-orders',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './admin-orders.html',
  styleUrls: ['./admin-orders.css']
})
export class AdminOrdersComponent {

  orders: any[] = [];
  loading = true;
  error = '';

  totalOrders = 0;
  totalRevenue = 0;

  constructor(private orderService: OrderService, private toastr: ToastrService) {}

  ngOnInit() {
    this.loadOrders();
  }

  loadOrders() {
    this.orderService.getAllOrders().subscribe({
      next: (res: any) => {
        console.log('ADMIN ORDERS:', res);

        // IMPORTANT: backend returns { data: [] }
        this.orders = res.data || [];

        //  Dashboard Calculations
        this.totalOrders = this.orders.length;
        this.loading = false;
      },
      error: (err:any) => {
        console.error(err);
        this.toastr.error ('Failed to load orders');
        this.loading = false;
      }
    });
  }
}