import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { ProductService } from '../../services/product.service';
import { CartService } from '../../services/cart.service';
import { CategoryService } from '../../services/category.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './product-list.component.html'
})
export class ProductListComponent implements OnInit {

  products: any[] = [];
  categories: string[] = [];

  selectedCategory: string = 'all';
  searchText = '';

  minPrice = 0;
  maxPrice = 100000;
  sortOption = '';

  loading = true;

  // PAGINATION
  currentPage = 1;
  pageSize = 6;

  constructor(
    private productService: ProductService,
    private categoryService: CategoryService,
    private cartService: CartService,
    private toastr: ToastrService,
    private cdr: ChangeDetectorRef,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  // ======================
  // INIT
  // ======================
  ngOnInit() {

    // Sync URL → state
    this.route.queryParams.subscribe(params => {
      this.selectedCategory = params['category'] || 'all';
      this.searchText = params['search'] || '';
      this.loadProducts();
    });

    this.loadCategories();
  }

  // ======================
  // LOAD PRODUCTS (FIXED)
  // ======================
  loadProducts() {
  this.loading = true;

  console.log("CATEGORY SENT:", this.selectedCategory);

  this.productService.getFilteredProducts(
    this.selectedCategory,
    this.searchText,
    this.minPrice,
    this.maxPrice
  ).subscribe({
    next: (data) => {
      console.log("API RESPONSE:", data); 

      this.products = data;
      this.loading = false;
      this.currentPage = 1;
      this.cdr.detectChanges();
    },
    error: () => {
      this.loading = false;
      this.toastr.error('Failed to load products');
    }
  });
}

  // ======================
  // LOAD CATEGORIES
  // ======================
  loadCategories() {
    this.categoryService.getCategories().subscribe({
      next: (data) => {
        this.categories = data;
      },
      error: () => {
        this.toastr.error('Failed to load categories');
      }
    });
  }

  // ======================
  // CATEGORY CLICK (URL BASED)
  // ======================
  selectCategory(category: string) {
    this.router.navigate([], {
      queryParams: {
        category: category === 'all' ? null : category
      },
      queryParamsHandling: 'merge'
    });
  }

  getDiscountedPrice(price: number, discount: number = 20): number {
  return Math.round(price - (price * discount) / 100);
}

getDiscountPercent(): number {
  return 20; // you can later make it dynamic per product
}

  // ======================
  // SEARCH (OPTIONAL IMPROVEMENT)
  // ======================
  onSearchChange() {
  this.currentPage = 1;

  this.router.navigate(['/products'], {
    queryParams: {
      search: this.searchText || null
    },
    queryParamsHandling: 'merge'
  });

  this.loadProducts(); // FORCE API CALL
}

  // ======================
  // FILTER + SORT (FRONTEND)
  // ======================
  get filteredProducts() {
    let result = [...this.products];

    // PRICE FILTER (backend already filtered, but keeping for UI)
    result = result.filter(p =>
      p.price >= this.minPrice && p.price <= this.maxPrice
    );

    // SORT
    if (this.sortOption === 'low-high') {
      result.sort((a, b) => a.price - b.price);
    } else if (this.sortOption === 'high-low') {
      result.sort((a, b) => b.price - a.price);
    }

    return result;
  }

  // ======================
  // PAGINATION
  // ======================
  get paginatedProducts() {
    const start = (this.currentPage - 1) * this.pageSize;
    return this.filteredProducts.slice(start, start + this.pageSize);
  }

  get totalPages() {
    return Math.ceil(this.filteredProducts.length / this.pageSize);
  }

  changePage(page: number) {
    this.currentPage = page;
  }

  // ======================
  // ADD TO CART
  // ======================
  addToCart(product: any) {

  // SAFE USER CHECK
  let user = null;

  try {
    const storedUser = localStorage.getItem('user');
    if (storedUser && storedUser !== 'undefined') {
      user = JSON.parse(storedUser);
    }
  } catch {
    user = null;
  }

  if (!user) {
    this.toastr.warning('Please login first!');
    this.router.navigate(['/login']);
    return;
  }

  this.cartService.add({
    productId: product.productId,
    name: product.name,
    price: product.price,
    imageUrl: product.imageUrl,
    quantity: 1
  });

  this.toastr.success('Added to cart');
}
}