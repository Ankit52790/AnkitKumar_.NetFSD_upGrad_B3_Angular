import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { CartService } from '../../services/cart.service';
import { AuthService } from '../../services/auth.service';
import { ProductService } from '../../services/product.service';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.css']
})
export class NavbarComponent implements OnInit {

  searchText: string = '';

  suggestions: any = {};
  showSuggestions = false;

  objectKeys = Object.keys;

  cartCount = 0;
  isLoggedIn = false;
  isAdmin = false;

  constructor(
    private cartService: CartService,
    private authService: AuthService,
    private productService: ProductService,
    private router: Router
  ) {}

  ngOnInit() {

    // SAFE AUTH INIT
    this.loadUserState();

    // CART COUNT
    this.cartService.cartCount$.subscribe(count => {
      this.cartCount = count;
    });
  }

  // ======================
  // AUTH STATE HANDLING (FIXED)
  // ======================
  loadUserState() {

  const user = this.authService.getUser();

  this.isLoggedIn = !!user;
  this.isAdmin = user?.role?.toLowerCase() === 'admin';
}

  // ======================
  // SEARCH
  // ======================
  onSearch() {
    const text = this.searchText.trim();
    if (!text) return;

    this.router.navigate(['/products'], {
      queryParams: { search: text }
    });

    this.showSuggestions = false;
  }

  // ======================
  // LIVE SEARCH
  // ======================
  onSearchChange() {

    const text = this.searchText.trim().toLowerCase();

    if (!text) {
      this.suggestions = {};
      this.showSuggestions = false;
      return;
    }

    this.productService.getProducts().subscribe({
      next: (data: any[]) => {

        const filtered = data.filter(p =>
          p.name.toLowerCase().includes(text)
        );

        const grouped: any = {};

        filtered.forEach(item => {
          const cat = item.category || 'Others';

          if (!grouped[cat]) {
            grouped[cat] = [];
          }

          grouped[cat].push(item);
        });

        this.suggestions = grouped;
        this.showSuggestions = Object.keys(grouped).length > 0;
      }
    });
  }

  // ======================
  // SELECT PRODUCT
  // ======================
  selectProduct(product: any) {

    this.searchText = product.name;
    this.showSuggestions = false;

    this.router.navigate(['/products', product.productId]);
  }

  // ======================
  // HIGHLIGHT
  // ======================
  highlightText(text: string): string {

    if (!this.searchText) return text;

    const regex = new RegExp(`(${this.searchText})`, 'gi');

    return text.replace(
      regex,
      `<mark style="background:#ffe066;padding:2px;border-radius:3px;">$1</mark>`
    );
  }

  // ======================
  // LOGOUT
  // ======================
  logout() {

    this.authService.logout();

    this.isLoggedIn = false;
    this.isAdmin = false;

    this.router.navigate(['/login']);
  }
}