import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';

export const adminGuard: CanActivateFn = () => {

  const router = inject(Router);

  const user = JSON.parse(localStorage.getItem('user') || 'null');

  if (!user || user.role?.toLowerCase() !== 'admin') {
    router.navigate(['/']);
    return false;
  }

  return true;
};